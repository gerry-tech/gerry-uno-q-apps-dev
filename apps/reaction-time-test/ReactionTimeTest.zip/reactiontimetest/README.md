# 😀 ReactionTimeTest

### Description

In questa app, viene realizzato un gioco per testare i tempi di reazione...

I pin sono intuibili dal codice...

### Se non lo fate seguitemi su YT : Gerry&Tech


