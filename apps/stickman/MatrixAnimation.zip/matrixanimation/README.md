# 💻 MatrixHack

### Description

In questa app abbiamo creato tramite l'esempio "LED Matrix Painter" dei frame che vengono inseriti nel loop, e tramite un delay tra i frame abbiamo un animazione.

PS: Se non lo fate già andate a seguirmi su YT: Gerry&Tech
Sul canale è presente il video "demo" dell'app con la spiegazione del codice!


