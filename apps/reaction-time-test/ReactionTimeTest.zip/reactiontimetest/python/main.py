# librerie
import time
import random
from arduino.app_utils import App, Bridge
from arduino.app_bricks.streamlit_ui import st

# sito web

st.title("Prova i tuoi Tempi di Reazione")

if st.button("Avvia Prova"):
    Bridge.call("ledrosso")

    delay = random.randint(1, 5)
    st.write("Tieniti pronto, inizierà a breve!")
    time.sleep(delay)

    Bridge.call("ledrosso_off")
    Bridge.call("ledverde")

    start = time.time()

    while True:
        valore = Bridge.call("valore_sensore")
        
        # Debug sistem
        # Se attivato printa il valore della fotoresistenza
        #st.write(f"Valore LDR: {valore}")
        
        if valore <= 250:
            end = time.time()
            Bridge.call("ledverde_off")
            break

        time.sleep(0.05)

    reazione = end - start
    st.success(f"Tempo di rezione: {reazione:.3f} secondi")