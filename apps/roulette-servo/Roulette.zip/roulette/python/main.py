import time
import random
from arduino.app_utils import App
from arduino.app_utils import Bridge



def loop():
    """This function is called repeatedly by the App framework."""
    # You can replace this with any code you want your App to run repeatedly.
    if (Bridge.call("valore") == 0):
        val = random.randint(1, 11)
        Bridge.call("suspence")
        if ((val >= 1) and (val <6)):
            Bridge.call("caso1")
            time.sleep(3)
            
        if ((val >= 6) and (val <9)):
            Bridge.call("caso2")
            time.sleep(3)

        if (val >= 9):
            Bridge.call ("caso3")
            time.sleep(3)
    
    Bridge.call("spegni")
    time.sleep(0.2)


# See: https://docs.arduino.cc/software/app-lab/tutorials/getting-started/#app-run
App.run(user_loop=loop)
