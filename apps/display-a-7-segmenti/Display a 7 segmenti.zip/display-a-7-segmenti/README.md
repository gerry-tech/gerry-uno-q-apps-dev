# 😀 Display a 7 segmenti

### Description

Ciao a tutti, questa è un app che permette di printare numeri tramite : un Display a 7 segmenti; sfruttando una pagina WEB

I pin potete vederli direttamente nel codice;


