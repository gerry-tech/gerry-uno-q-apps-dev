#importiamo le librerie
import time

from arduino.app_utils import App
from arduino.app_utils import Bridge
from arduino.app_bricks.streamlit_ui import st

#creiamo la pagina web usando Streamlit

st.title("Display a 7 Segmenti!")
st.write("Clicca i pulsanti per generare numeri")

if st.button("Disegna 1"):
    Bridge.call("num1")
    st.success("Resterà per 5 secondi")
    time.sleep(5)
    
if st.button("Disegna 2"):
    Bridge.call("num2")
    st.success("Resterà per 5 secondi")
    time.sleep(5)
    
if st.button("Disegna 3"):
    Bridge.call("num3")
    st.success("Resterà per 5 secondi")
    time.sleep(5)
    
if st.button("Disegna 4"):
    Bridge.call("num4")
    st.success("Resterà per 5 secondi")
    time.sleep(5)
    
if st.button("Disegna 5"):
    Bridge.call("num5")
    st.success("Resterà per 5 secondi")
    time.sleep(5)

if st.button("Disegna 6"):
    Bridge.call("num6")
    st.success("Resterà per 5 secondi")
    time.sleep(5)

if st.button("Disegna 7"):
    Bridge.call("num7")
    st.success("Resterà per 5 secondi")
    time.sleep(5)

if st.button("Disegna 8"):
    Bridge.call("num8")
    st.success("Resterà per 5 secondi")
    time.sleep(5)

if st.button("Disegna 9"):
    Bridge.call("num9")
    st.success("Resterà per 5 secondi")
    time.sleep(5)

if st.button("Mostra puntino"):
    Bridge.call("puntino")
    st.success("Resterà per 5 secondi")
    time.sleep(5)


Bridge.call("spegni")